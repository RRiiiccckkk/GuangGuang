from typing import Literal
from langchain_core.messages import HumanMessage, SystemMessage
from langchain_core.tools import tool
from langchain_openai import ChatOpenAI

from langgraph.graph import StateGraph, START, END, MessagesState
from langgraph.checkpoint.memory import MemorySaver
from langgraph.prebuilt import ToolNode

@tool
def search(query:str)->str:
    if "shanghai" in query.lower():
        return "shanghai is in china"
    return "i don't know"

tools=[search]

tool_node=ToolNode(tools)

model=ChatOpenAI(model="deepseek-chat",temperature=0,base_url="https://api.deepseek.com",api_key="sk-1234567890")

def should_continue(state:MessagesState)-> Literal["tools",END]:
    messages = state["messages"]
    last_message=messages[-1]
    if last_message.tool_calls:
        return "tools"
    return END

def call_model(state:MessagesState)->MessagesState:
    messages=state["messages"]
    response=model.invoke(messages)
    return {"messages":[response]}

workflow=StateGraph(MessagesState)
workflow.add_node("agent", call_model)
workflow.add_node("tools",tool_node)

workflow.set_entry_point("agent")

workflow.add_conditional_edges(
    "agent",
    should_continue
)

workflow.add_edge("tools","agent")

checkpoint=MemorySaver()

app=workflow.compile(checkpoint=checkpoint)

final_state=app.invoke(
    {"messages":[HumanMessage(content="Where is shanghai?")]},
    config={"configurable":{"thread_id":"123"}})

result=final_state["messages"][-1].content
print(result)
final_state=app.invoke(
    {"messages":[HumanMessage(content="Where is beijing?")]},
    config={"configurable":{"thread_id":"123"}})
result=final_state["messages"][-1].content
print(result)


