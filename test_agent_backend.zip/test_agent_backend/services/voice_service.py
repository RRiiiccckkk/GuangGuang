"""
Voice service for handling audio processing and responses.
"""

import logging
import json
import base64
from typing import Dict, Optional, AsyncGenerator

# 直接导入管理器
from speech.asr.asr_manager import ASRManager
from speech.tts.tts_manager import TTSManager, VoiceMode
from agent.graph.build_graph import build_graph
from langgraph.graph import MessagesState
from langchain_core.messages import HumanMessage, AIMessage, AIMessageChunk
from config.settings import settings

logger = logging.getLogger(__name__)

class VoiceService:
    """Service for handling voice interactions."""
    
    def __init__(self):
        """Initialize voice service."""
        self.asr_manager = ASRManager()
        self.tts_manager = TTSManager()
        # 构建LangGraph agent工作流
        self.agent_graph = build_graph()
        # 会话状态管理 - 使用MessagesState
        self.sessions: Dict[str, MessagesState] = {}
        
    def get_or_create_session(self, session_id: str) -> MessagesState:
        """获取或创建会话状态"""
        if session_id not in self.sessions:
            self.sessions[session_id] = MessagesState(messages=[])
        return self.sessions[session_id]
        
    async def process_audio(self, audio_data: str, sample_rate: int, session_id: str) -> AsyncGenerator[Dict, None]:
        """Process audio input and generate streaming response.
        
        Args:
            audio_data: Base64 encoded audio data
            sample_rate: Audio sample rate
            session_id: Session identifier
            
        Yields:
            Dictionary containing response data
        """
        try:
            # Decode base64 audio
            audio_bytes = base64.b64decode(audio_data)
            
            # Perform speech recognition
            asr_result = await self.asr_manager.process_audio_bytes(audio_bytes, sample_rate)
            text = asr_result["text"]
            
            # Send ASR result - 保持现有消息格式
            yield {
                "type": "asr_result",
                "text": text,
                "status": asr_result["status"]
            }
            
            # Get chat session
            session = self.get_or_create_session(session_id)
            
            # 添加用户消息到会话
            session.messages.append(HumanMessage(content=text))
            
            # 调用LangGraph agent工作流 - 流式处理
            try:
                # 流式调用agent工作流
                ai_response = ""
                async for chunk in self.agent_graph.astream(
                    session,
                    config={"configurable": {"thread_id": session_id}}
                ):
                    # 处理流式响应 - 修复：正确处理LangGraph的流式输出格式
                    logger.debug(f"Received chunk: {chunk}")
                    
                    # LangGraph的流式输出可能包含不同的键
                    if isinstance(chunk, dict):
                        # 检查是否有messages键
                        if "messages" in chunk:
                            messages = chunk["messages"]
                            # 获取最新的AI消息
                            ai_messages = [msg for msg in messages if isinstance(msg, (AIMessage, AIMessageChunk))] 
                            if ai_messages:
                                latest_ai_message = ai_messages[-1]
                                if hasattr(latest_ai_message, 'content') and latest_ai_message.content:
                                    ai_response = latest_ai_message.content
                                    
                                    # 流式TTS生成 - 修复：每个音频块立即发送
                                    try:
                                        async for audio_chunk in self.tts_manager.stream_tts(
                                            ai_response, 
                                            voice_mode=VoiceMode.NORMAL
                                        ):
                                            if audio_chunk:
                                                # 每个音频块立即编码并发送
                                                audio_b64 = base64.b64encode(audio_chunk).decode('utf-8')
                                                
                                                # 发送音频块
                                                yield {
                                                    "type": "audio_chunk",
                                                    "audio": audio_b64,
                                                    "status": {"code": settings.STATUS_SUCCESS, "message": "Audio chunk"}
                                                }
                                        
                                        # 发送文本响应（在音频发送完毕后）
                                        yield {
                                            "type": "response",
                                            "text": ai_response,
                                            "status": {"code": settings.STATUS_SUCCESS, "message": "Success"}
                                        }
                                        
                                    except Exception as e:
                                        logger.error(f"TTS generation failed: {str(e)}")
                                        # 即使TTS失败，也要发送文本响应
                                        yield {
                                            "type": "response",
                                            "text": ai_response,
                                            "status": {"code": settings.STATUS_PROCESSING_ERROR, "message": f"TTS failed: {str(e)}"}
                                        }
                        else:
                            # 如果没有messages键，记录chunk内容以便调试
                            logger.debug(f"Chunk without messages: {chunk}")
                    else:
                        # 如果chunk不是字典，记录其类型和内容
                        logger.debug(f"Chunk is not dict: {type(chunk)}, content: {chunk}")
                
                # 更新会话状态
                # self.sessions[session_id] = session
                
                # 如果没有AI响应，发送默认消息
                if not ai_response:
                    yield {
                        "type": "response",
                        "text": "抱歉，我没有理解您的问题",
                        "status": {"code": settings.STATUS_AUDIO_FORMAT_ERROR, "message": "No AI response generated"}
                    }
                    
            except Exception as e:
                logger.error(f"Agent processing failed: {str(e)}")
                yield {
                    "type": "response",
                    "text": f"处理失败：{str(e)}",
                    "status": {"code": settings.STATUS_PROCESSING_ERROR, "message": f"Agent failed: {str(e)}"}
                }
            
        except Exception as e:
            logger.error(f"Error processing audio: {str(e)}")
            yield {
                "type": "error",
                "text": f"处理失败：{str(e)}",
                "status": {"code": settings.STATUS_PROCESSING_ERROR, "message": str(e)}
            }
    
    async def close(self):
        """Close voice service and cleanup resources."""
        try:
            # 清理会话状态
            self.sessions.clear()
            # 关闭TTS管理器
            await self.tts_manager.close()
            # ASR管理器没有close方法，跳过
        except Exception as e:
            logger.error(f"Error closing voice service: {str(e)}") 