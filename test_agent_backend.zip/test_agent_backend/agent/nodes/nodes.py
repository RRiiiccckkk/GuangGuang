"""
LangGraph节点定义文件

这个文件包含了智能体工作流中使用的所有节点定义。

包含内容：
1. 工具节点 (ToolNode) - 处理各种工具调用
2. 智能体节点 (AgentNode) - 处理LLM对话
3. 路由节点 - 决定工作流下一步执行
4. 条件函数 - 控制工作流分支逻辑

使用方式：
- 在其他文件中导入这些节点
- 在workflow.py或main.py中构建完整的工作流
- 通过StateGraph连接各个节点

示例：
    from agent.nodes.nodes import tool_node, agent_node
    workflow = StateGraph(MessagesState)
    workflow.add_node("agent", agent_node)
    workflow.add_node("tools", tool_node)
"""

from langgraph.graph import START, END, StateGraph, MessagesState
from langgraph.prebuilt import ToolNode
from langchain_core.tools import tool
from langchain_openai import ChatOpenAI
from config.settings import settings

# 简单的同步工具
@tool
def search_shanghai_location(query: str) -> str:
    """搜索网络信息"""
    if "shanghai" in query.lower():
        return "shanghai is in china"
    return "i don't know"

# 工具列表,
tools = [search_shanghai_location]

# 工具节点
tool_node = ToolNode(tools)

# 初始化模型
# model = ChatOpenAI(
#     model="deepseek-chat",
#     temperature=0,
#     base_url="https://api.deepseek.com",
#     api_key="sk-da5d08fe18c1470db0c40bc874784a59"
# ).bind_tools(tools)

model = ChatOpenAI(
    model_name="qwen-turbo",  # 千问模型名称
    base_url="https://dashscope.aliyuncs.com/compatible-mode/v1",  # 千问兼容OpenAI的API地址
    api_key="sk-ada2984befea47bc946fa1dff0937488",  # 同上
    temperature=0,
    streaming=True,
    timeout=5,
).bind_tools(tools)


def agent_node(state: MessagesState) -> MessagesState:
    """智能体节点，处理用户消息并生成回复"""
    # 直接在原始状态上修改（关键修复）
    # 1. 调用模型获取响应
    response = model.invoke(state.messages)
    # 2. 将响应添加到原始状态的消息列表中（而非创建新实例）
    state.messages.append(response)
    # 3. 返回原始状态（保持类型一致性）
    return state
    

