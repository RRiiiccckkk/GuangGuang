from langgraph.graph import StateGraph, START, END, MessagesState
from typing import Literal

from agent.nodes.nodes import agent_node, tool_node
# from agent.state.agent_state import AgentState
#先使用MessagesState简化操作

def build_graph() -> StateGraph:
    """构建智能体工作流图"""
    graph = StateGraph(MessagesState)

    # 添加节点
    graph.add_node("agent", agent_node)
    graph.add_node("tool", tool_node)

    # 设置入口点
    graph.set_entry_point("agent")

    def decide_next_node(state: MessagesState) -> Literal["tool", END]:
        """决定下一步执行哪个节点"""
        # 在MessagesState中，状态是字典格式
        messages = state.messages
        last_message = messages[-1] if messages else None
        
        # 检查最后一条消息是否有工具调用
        if last_message and hasattr(last_message, 'tool_calls') and last_message.tool_calls:
            return "tool"
        # 否则结束工作流
        else:
            return END

    # 添加条件边
    graph.add_conditional_edges(
        "agent",
        decide_next_node,
        {
            "tool": "tool",
            END: END
        }
    )

    # 添加工具执行后的边 - 工具执行完后总是回到agent
    graph.add_edge("tool", "agent")

    return graph.compile()