"""
Agent状态定义 - 流转的数据载体
先搁置，使用MessagesState,后期优化再使用AgentState
"""
import logging
from typing import Dict, Any, List, Optional
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum


class MessageType(Enum):
    """消息类型枚举"""
    USER = "user"
    ASSISTANT = "assistant"
    SYSTEM = "system"
    TOOL = "tool"


class VoiceType(Enum):
    """音色类型枚举"""
    DEFAULT = "default"
    PRESIDENT = "president"
    ASSISTANT = "assistant"


@dataclass
class Message:
    """消息类"""
    type: MessageType
    content: str
    timestamp: datetime = field(default_factory=datetime.now)
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ToolCall:
    """工具调用类"""
    tool_name: str
    parameters: Dict[str, Any]
    result: Optional[Any] = None
    timestamp: datetime = field(default_factory=datetime.now)
    success: bool = True
    error: Optional[str] = None


@dataclass
class AgentState:
    """Agent状态类"""
    
    # 对话相关
    messages: List[Message] = field(default_factory=list)
    current_query: str = ""
    current_response: str = ""
    
    # 工具相关
    tool_calls: List[ToolCall] = field(default_factory=list)
    available_tools: List[str] = field(default_factory=list)
    
    # 语音相关
    voice_type: VoiceType = VoiceType.DEFAULT
    audio_input: Optional[bytes] = None
    audio_output: Optional[bytes] = None
    
    # 记忆相关
    conversation_memory: List[Dict[str, Any]] = field(default_factory=list)
    context_window: int = 10  # 上下文窗口大小
    
    # 会话相关
    session_id: str = ""
    user_id: str = ""
    start_time: datetime = field(default_factory=datetime.now)
    
    # 状态标志
    is_processing: bool = False
    has_error: bool = False
    error_message: str = ""
    
    # 元数据
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def add_message(self, message_type: MessageType, content: str, metadata: Optional[Dict[str, Any]] = None):
        """
        添加消息
        
        Args:
            message_type: 消息类型
            content: 消息内容
            metadata: 元数据
        """
        message = Message(
            type=message_type,
            content=content,
            metadata=metadata or {}
        )
        self.messages.append(message)
        
        # 更新对话记忆
        if message_type in [MessageType.USER, MessageType.ASSISTANT]:
            self._update_conversation_memory(message)
    
    def add_tool_call(self, tool_name: str, parameters: Dict[str, Any], result: Any = None, success: bool = True, error: str = None):
        """
        添加工具调用
        
        Args:
            tool_name: 工具名称
            parameters: 工具参数
            result: 工具结果
            success: 是否成功
            error: 错误信息
        """
        tool_call = ToolCall(
            tool_name=tool_name,
            parameters=parameters,
            result=result,
            success=success,
            error=error
        )
        self.tool_calls.append(tool_call)
    
    def set_current_query(self, query: str):
        """
        设置当前查询
        
        Args:
            query: 查询内容
        """
        self.current_query = query
    
    def set_current_response(self, response: str):
        """
        设置当前响应
        
        Args:
            response: 响应内容
        """
        self.current_response = response
    
    def set_voice_type(self, voice_type: VoiceType):
        """
        设置音色类型
        
        Args:
            voice_type: 音色类型
        """
        self.voice_type = voice_type
    
    def set_audio_input(self, audio_data: bytes):
        """
        设置音频输入
        
        Args:
            audio_data: 音频数据
        """
        self.audio_input = audio_data
    
    def set_audio_output(self, audio_data: bytes):
        """
        设置音频输出
        
        Args:
            audio_data: 音频数据
        """
        self.audio_output = audio_data
    
    def _update_conversation_memory(self, message: Message):
        """
        更新对话记忆
        
        Args:
            message: 消息对象
        """
        memory_entry = {
            'type': message.type.value,
            'content': message.content,
            'timestamp': message.timestamp.isoformat(),
            'metadata': message.metadata
        }
        
        self.conversation_memory.append(memory_entry)
        
        # 保持记忆大小在限制范围内
        if len(self.conversation_memory) > self.context_window * 2:
            self.conversation_memory = self.conversation_memory[-self.context_window:]
    
    def get_recent_messages(self, count: int = 5) -> List[Message]:
        """
        获取最近的消息
        
        Args:
            count: 消息数量
            
        Returns:
            消息列表
        """
        return self.messages[-count:] if self.messages else []
    
    def get_conversation_context(self) -> str:
        """
        获取对话上下文
        
        Returns:
            对话上下文字符串
        """
        context_parts = []
        
        # 添加最近的对话
        recent_messages = self.get_recent_messages(self.context_window)
        for message in recent_messages:
            if message.type == MessageType.USER:
                context_parts.append(f"用户: {message.content}")
            elif message.type == MessageType.ASSISTANT:
                context_parts.append(f"助手: {message.content}")
        
        return "\n".join(context_parts)
    
    def get_tool_calls_summary(self) -> str:
        """
        获取工具调用摘要
        
        Returns:
            工具调用摘要字符串
        """
        if not self.tool_calls:
            return ""
        
        summary_parts = []
        for tool_call in self.tool_calls[-3:]:  # 最近3次工具调用
            status = "成功" if tool_call.success else "失败"
            summary_parts.append(f"工具 {tool_call.tool_name}: {status}")
        
        return "; ".join(summary_parts)
    
    def set_error(self, error_message: str):
        """
        设置错误状态
        
        Args:
            error_message: 错误信息
        """
        self.has_error = True
        self.error_message = error_message
        self.is_processing = False
    
    def clear_error(self):
        """清除错误状态"""
        self.has_error = False
        self.error_message = ""
    
    def reset_conversation(self):
        """重置对话状态"""
        self.messages.clear()
        self.tool_calls.clear()
        self.conversation_memory.clear()
        self.current_query = ""
        self.current_response = ""
        self.audio_input = None
        self.audio_output = None
        self.clear_error()
    
    def to_dict(self) -> Dict[str, Any]:
        """
        转换为字典
        
        Returns:
            状态字典
        """
        return {
            'session_id': self.session_id,
            'user_id': self.user_id,
            'current_query': self.current_query,
            'current_response': self.current_response,
            'voice_type': self.voice_type.value,
            'messages_count': len(self.messages),
            'tool_calls_count': len(self.tool_calls),
            'conversation_memory_count': len(self.conversation_memory),
            'is_processing': self.is_processing,
            'has_error': self.has_error,
            'error_message': self.error_message,
            'start_time': self.start_time.isoformat(),
            'metadata': self.metadata
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'AgentState':
        """
        从字典创建状态
        
        Args:
            data: 状态字典
            
        Returns:
            Agent状态对象
        """
        state = cls()
        state.session_id = data.get('session_id', '')
        state.user_id = data.get('user_id', '')
        state.current_query = data.get('current_query', '')
        state.current_response = data.get('current_response', '')
        state.voice_type = VoiceType(data.get('voice_type', 'default'))
        state.is_processing = data.get('is_processing', False)
        state.has_error = data.get('has_error', False)
        state.error_message = data.get('error_message', '')
        state.metadata = data.get('metadata', {})
        
        # 解析时间
        start_time_str = data.get('start_time', '')
        if start_time_str:
            state.start_time = datetime.fromisoformat(start_time_str)
        
        return state


class StateManager:
    """状态管理器类"""
    
    def __init__(self):
        """初始化状态管理器"""
        self.logger = logging.getLogger(__name__)
        self.states: Dict[str, AgentState] = {}
    
    def create_state(self, session_id: str, user_id: str = "") -> AgentState:
        """
        创建新的状态
        
        Args:
            session_id: 会话ID
            user_id: 用户ID
            
        Returns:
            新的Agent状态
        """
        state = AgentState()
        state.session_id = session_id
        state.user_id = user_id
        state.start_time = datetime.now()
        
        self.states[session_id] = state
        self.logger.info(f"创建新状态: {session_id}")
        
        return state
    
    def get_state(self, session_id: str) -> Optional[AgentState]:
        """
        获取状态
        
        Args:
            session_id: 会话ID
            
        Returns:
            Agent状态
        """
        return self.states.get(session_id)
    
    def update_state(self, session_id: str, state: AgentState):
        """
        更新状态
        
        Args:
            session_id: 会话ID
            state: 状态对象
        """
        self.states[session_id] = state
    
    def delete_state(self, session_id: str):
        """
        删除状态
        
        Args:
            session_id: 会话ID
        """
        if session_id in self.states:
            del self.states[session_id]
            self.logger.info(f"删除状态: {session_id}")
    
    def cleanup_expired_states(self, max_age_hours: int = 24):
        """
        清理过期的状态
        
        Args:
            max_age_hours: 最大保留时间（小时）
        """
        current_time = datetime.now()
        expired_sessions = []
        
        for session_id, state in self.states.items():
            age = current_time - state.start_time
            if age.total_seconds() > max_age_hours * 3600:
                expired_sessions.append(session_id)
        
        for session_id in expired_sessions:
            self.delete_state(session_id)
        
        if expired_sessions:
            self.logger.info(f"清理了 {len(expired_sessions)} 个过期状态")
    
    def get_active_sessions_count(self) -> int:
        """
        获取活跃会话数量
        
        Returns:
            活跃会话数量
        """
        return len(self.states)
    
    def get_session_summary(self) -> Dict[str, Any]:
        """
        获取会话摘要
        
        Returns:
            会话摘要信息
        """
        return {
            'total_sessions': len(self.states),
            'active_sessions': len([s for s in self.states.values() if s.is_processing]),
            'sessions_with_errors': len([s for s in self.states.values() if s.has_error])
        }


# 全局状态管理器实例
state_manager = StateManager() 