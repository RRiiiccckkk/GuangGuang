"""
Main application entry point.
"""

import logging
import json
from typing import Dict, Any

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware

from websocket.handler import audio_chat_handler
from core.auth import auth_manager

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

app = FastAPI()

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.websocket("/api/audio-chat")
async def websocket_endpoint(websocket: WebSocket):
    """WebSocket endpoint for audio chat."""
    client_id = str(id(websocket))
    
    try:
        # Validate token
        token = websocket.query_params.get("token")
        if not token or not auth_manager.validate_token(token):
            await websocket.close(code=4003, reason="Authentication failed")
            return
            
        # Accept connection
        await audio_chat_handler.connect(websocket, client_id)
        
        # Handle messages
        while True:
            try:
                # Receive and parse message
                message = await websocket.receive_json()
                await audio_chat_handler.handle_message(websocket, client_id, message)
                
            except json.JSONDecodeError:
                logger.error("Failed to decode message")
                await websocket.send_json({
                    "type": "error",
                    "text": "Invalid message format",
                    "status": {"code": 1002, "message": "JSON decode error"}
                })
                
    except WebSocketDisconnect:
        logger.info(f"Client disconnected: {client_id}")
        audio_chat_handler.disconnect(client_id)
        
    except Exception as e:
        logger.error(f"WebSocket error: {str(e)}")
        try:
            await websocket.send_json({
                "type": "error",
                "text": "WebSocket error",
                "status": {"code": 1002, "message": str(e)}
            })
        except:
            pass
        
    finally:
        audio_chat_handler.disconnect(client_id)

@app.get("/api/token")
async def get_token() -> Dict[str, Any]:
    """Get development token."""
    return {
        "token": "dev_token_1691062800",
        "expires_in": 3600
    }

def main():
    """Main application entry point."""
    import uvicorn
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="debug"
    )

if __name__ == "__main__":
    main() 