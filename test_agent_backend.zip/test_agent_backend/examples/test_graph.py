
import os
import sys

# Add the project root directory to the Python path
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.abspath(os.path.join(current_dir, '../'))
sys.path.append(project_root)


from agent.graph.build_graph import build_graph
# from agent.state.agent_state import AgentState
from langchain_core.messages import HumanMessage

def test_graph():
    # 1. 构建graph（调用你在build_graph.py中定义的函数）
    graph = build_graph()

    # 2. 定义初始状态（根据你的state结构设置）
    # 假设你的state包含"messages"字段（用户输入）
    initial_state = {
        "messages": [
            HumanMessage(content="Where is shanghai?")
        ]
        # 若有其他字段（如session_id），也需要在这里初始化
        # "session_id": "test_123"
    }

    # 3. 运行graph（同步调用，适合调试）
    result = graph.invoke(initial_state,config={"configurable":{"thread_id":"123"}})

    # 4. 打印结果，观察流程是否符合预期
    print("最终状态：")
    for msg in result["messages"]:
        print(f"{msg.type}: {msg.content}")


# 在test_graph.py中添加流式测试函数
def test_graph_stream():
    graph = build_graph()
    initial_state = {
        "messages": [HumanMessage(content="Where is shanghai?")]
    }

    # 流式调用，逐段获取结果
    print("\n流式输出：")
    for token, metadata in graph.stream(initial_state, stream_mode="messages"):
        # 打印每个chunk的内容（根据你的stream_mode调整解析逻辑）
        content=token.content
        print(content,end="",flush=True)
    print()  # 换行

if __name__ == "__main__":
    # test_graph()
    test_graph_stream()  # 新增流式测试
