"""
缓存工具 - 缓存（高频RAG结果、工具调用结果）
"""
import logging
import time
import hashlib
import json
from typing import Dict, Any, Optional, List
from datetime import datetime, timedelta
from collections import OrderedDict


class CacheEntry:
    """缓存条目类"""
    
    def __init__(self, key: str, value: Any, ttl: int = 3600):
        """
        初始化缓存条目
        
        Args:
            key: 缓存键
            value: 缓存值
            ttl: 生存时间（秒）
        """
        self.key = key
        self.value = value
        self.created_at = datetime.now()
        self.last_accessed = datetime.now()
        self.ttl = ttl
        self.access_count = 0
    
    def is_expired(self) -> bool:
        """
        检查是否过期
        
        Returns:
            是否过期
        """
        return datetime.now() > self.created_at + timedelta(seconds=self.ttl)
    
    def access(self):
        """访问缓存条目"""
        self.last_accessed = datetime.now()
        self.access_count += 1
    
    def to_dict(self) -> Dict[str, Any]:
        """
        转换为字典
        
        Returns:
            字典表示
        """
        return {
            'key': self.key,
            'value': self.value,
            'created_at': self.created_at.isoformat(),
            'last_accessed': self.last_accessed.isoformat(),
            'ttl': self.ttl,
            'access_count': self.access_count,
            'is_expired': self.is_expired()
        }


class LRUCache:
    """LRU缓存类"""
    
    def __init__(self, max_size: int = 1000):
        """
        初始化LRU缓存
        
        Args:
            max_size: 最大缓存条目数
        """
        self.max_size = max_size
        self.cache: OrderedDict[str, CacheEntry] = OrderedDict()
    
    def get(self, key: str) -> Optional[Any]:
        """
        获取缓存值
        
        Args:
            key: 缓存键
            
        Returns:
            缓存值
        """
        if key in self.cache:
            entry = self.cache[key]
            
            # 检查是否过期
            if entry.is_expired():
                del self.cache[key]
                return None
            
            # 更新访问信息
            entry.access()
            
            # 移动到末尾（最近使用）
            self.cache.move_to_end(key)
            
            return entry.value
        
        return None
    
    def set(self, key: str, value: Any, ttl: int = 3600):
        """
        设置缓存值
        
        Args:
            key: 缓存键
            value: 缓存值
            ttl: 生存时间（秒）
        """
        # 如果键已存在，先删除
        if key in self.cache:
            del self.cache[key]
        
        # 如果缓存已满，删除最久未使用的条目
        if len(self.cache) >= self.max_size:
            oldest_key = next(iter(self.cache))
            del self.cache[oldest_key]
        
        # 创建新的缓存条目
        entry = CacheEntry(key, value, ttl)
        self.cache[key] = entry
    
    def delete(self, key: str):
        """
        删除缓存条目
        
        Args:
            key: 缓存键
        """
        if key in self.cache:
            del self.cache[key]
    
    def clear(self):
        """清空缓存"""
        self.cache.clear()
    
    def cleanup_expired(self):
        """清理过期条目"""
        expired_keys = []
        for key, entry in self.cache.items():
            if entry.is_expired():
                expired_keys.append(key)
        
        for key in expired_keys:
            del self.cache[key]
    
    def get_stats(self) -> Dict[str, Any]:
        """
        获取缓存统计信息
        
        Returns:
            统计信息字典
        """
        total_entries = len(self.cache)
        expired_entries = sum(1 for entry in self.cache.values() if entry.is_expired())
        
        if total_entries > 0:
            avg_access_count = sum(entry.access_count for entry in self.cache.values()) / total_entries
        else:
            avg_access_count = 0
        
        return {
            'total_entries': total_entries,
            'expired_entries': expired_entries,
            'max_size': self.max_size,
            'usage_percentage': (total_entries / self.max_size) * 100,
            'avg_access_count': avg_access_count
        }


class CacheManager:
    """缓存管理器类"""
    
    def __init__(self):
        """初始化缓存管理器"""
        self.logger = logging.getLogger(__name__)
        self.caches: Dict[str, LRUCache] = {}
        self.default_ttl = 3600  # 默认1小时
        self.default_max_size = 1000
    
    def get_cache(self, name: str, max_size: int = None) -> LRUCache:
        """
        获取或创建缓存
        
        Args:
            name: 缓存名称
            max_size: 最大大小
            
        Returns:
            LRU缓存实例
        """
        if name not in self.caches:
            size = max_size or self.default_max_size
            self.caches[name] = LRUCache(size)
            self.logger.info(f"创建缓存: {name}, 最大大小: {size}")
        
        return self.caches[name]
    
    def get(self, cache_name: str, key: str) -> Optional[Any]:
        """
        从指定缓存获取值
        
        Args:
            cache_name: 缓存名称
            key: 缓存键
            
        Returns:
            缓存值
        """
        cache = self.get_cache(cache_name)
        return cache.get(key)
    
    def set(self, cache_name: str, key: str, value: Any, ttl: int = None):
        """
        向指定缓存设置值
        
        Args:
            cache_name: 缓存名称
            key: 缓存键
            value: 缓存值
            ttl: 生存时间（秒）
        """
        cache = self.get_cache(cache_name)
        ttl = ttl or self.default_ttl
        cache.set(key, value, ttl)
    
    def delete(self, cache_name: str, key: str):
        """
        从指定缓存删除值
        
        Args:
            cache_name: 缓存名称
            key: 缓存键
        """
        if cache_name in self.caches:
            self.caches[cache_name].delete(key)
    
    def clear_cache(self, cache_name: str):
        """
        清空指定缓存
        
        Args:
            cache_name: 缓存名称
        """
        if cache_name in self.caches:
            self.caches[cache_name].clear()
            self.logger.info(f"清空缓存: {cache_name}")
    
    def cleanup_all(self):
        """清理所有过期的缓存条目"""
        for name, cache in self.caches.items():
            cache.cleanup_expired()
        self.logger.info("清理所有过期缓存条目")
    
    def get_all_stats(self) -> Dict[str, Any]:
        """
        获取所有缓存的统计信息
        
        Returns:
            统计信息字典
        """
        stats = {}
        for name, cache in self.caches.items():
            stats[name] = cache.get_stats()
        
        return stats
    
    def generate_cache_key(self, *args, **kwargs) -> str:
        """
        生成缓存键
        
        Args:
            *args: 位置参数
            **kwargs: 关键字参数
            
        Returns:
            缓存键
        """
        # TODO: 实现缓存键生成
        # 1. 序列化参数
        # 2. 生成哈希值
        # 3. 返回缓存键
        
        # 创建参数字典
        key_data = {
            'args': args,
            'kwargs': sorted(kwargs.items())
        }
        
        # 序列化为JSON字符串
        key_string = json.dumps(key_data, sort_keys=True, ensure_ascii=False)
        
        # 生成MD5哈希
        key_hash = hashlib.md5(key_string.encode('utf-8')).hexdigest()
        
        return key_hash


class RAGCache:
    """RAG结果缓存类"""
    
    def __init__(self, cache_manager: CacheManager):
        """
        初始化RAG缓存
        
        Args:
            cache_manager: 缓存管理器
        """
        self.cache_manager = cache_manager
        self.cache_name = "rag_results"
        self.logger = logging.getLogger(__name__)
    
    def get_rag_result(self, query: str, category: str = None) -> Optional[Dict[str, Any]]:
        """
        获取RAG结果
        
        Args:
            query: 查询内容
            category: 查询类别
            
        Returns:
            RAG结果
        """
        cache_key = self._generate_rag_key(query, category)
        return self.cache_manager.get(self.cache_name, cache_key)
    
    def set_rag_result(self, query: str, result: Dict[str, Any], category: str = None, ttl: int = 1800):
        """
        设置RAG结果
        
        Args:
            query: 查询内容
            result: 查询结果
            category: 查询类别
            ttl: 生存时间（秒）
        """
        cache_key = self._generate_rag_key(query, category)
        self.cache_manager.set(self.cache_name, cache_key, result, ttl)
        self.logger.debug(f"缓存RAG结果: {cache_key}")
    
    def _generate_rag_key(self, query: str, category: str = None) -> str:
        """
        生成RAG缓存键
        
        Args:
            query: 查询内容
            category: 查询类别
            
        Returns:
            缓存键
        """
        key_data = {
            'type': 'rag',
            'query': query.lower().strip(),
            'category': category or 'all'
        }
        
        key_string = json.dumps(key_data, sort_keys=True, ensure_ascii=False)
        return hashlib.md5(key_string.encode('utf-8')).hexdigest()


class ToolCache:
    """工具调用结果缓存类"""
    
    def __init__(self, cache_manager: CacheManager):
        """
        初始化工具缓存
        
        Args:
            cache_manager: 缓存管理器
        """
        self.cache_manager = cache_manager
        self.cache_name = "tool_results"
        self.logger = logging.getLogger(__name__)
    
    def get_tool_result(self, tool_name: str, parameters: Dict[str, Any]) -> Optional[Any]:
        """
        获取工具调用结果
        
        Args:
            tool_name: 工具名称
            parameters: 工具参数
            
        Returns:
            工具调用结果
        """
        cache_key = self._generate_tool_key(tool_name, parameters)
        return self.cache_manager.get(self.cache_name, cache_key)
    
    def set_tool_result(self, tool_name: str, parameters: Dict[str, Any], result: Any, ttl: int = 3600):
        """
        设置工具调用结果
        
        Args:
            tool_name: 工具名称
            parameters: 工具参数
            result: 调用结果
            ttl: 生存时间（秒）
        """
        cache_key = self._generate_tool_key(tool_name, parameters)
        self.cache_manager.set(self.cache_name, cache_key, result, ttl)
        self.logger.debug(f"缓存工具结果: {tool_name}")
    
    def _generate_tool_key(self, tool_name: str, parameters: Dict[str, Any]) -> str:
        """
        生成工具缓存键
        
        Args:
            tool_name: 工具名称
            parameters: 工具参数
            
        Returns:
            缓存键
        """
        key_data = {
            'type': 'tool',
            'tool_name': tool_name,
            'parameters': sorted(parameters.items())
        }
        
        key_string = json.dumps(key_data, sort_keys=True, ensure_ascii=False)
        return hashlib.md5(key_string.encode('utf-8')).hexdigest()


# 全局缓存管理器实例
cache_manager = CacheManager()

# 创建专门的缓存实例
rag_cache = RAGCache(cache_manager)
tool_cache = ToolCache(cache_manager) 