"""
日志记录器 - 延迟监控、错误追踪
"""
import logging
import logging.handlers
import os
import sys
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, Optional
import time
import functools

from core.config_loader import config_loader


class PerformanceLogger:
    """性能日志记录器"""
    
    def __init__(self, logger: logging.Logger):
        """初始化性能日志记录器"""
        self.logger = logger
        self.start_times: Dict[str, float] = {}
    
    def start_timer(self, operation: str):
        """
        开始计时
        
        Args:
            operation: 操作名称
        """
        self.start_times[operation] = time.time()
    
    def end_timer(self, operation: str, extra_info: Optional[Dict[str, Any]] = None):
        """
        结束计时并记录
        
        Args:
            operation: 操作名称
            extra_info: 额外信息
        """
        if operation in self.start_times:
            duration = time.time() - self.start_times[operation]
            info = f"操作 {operation} 耗时: {duration:.3f}秒"
            
            if extra_info:
                info += f", 额外信息: {extra_info}"
            
            if duration > 1.0:  # 超过1秒的操作记录为警告
                self.logger.warning(info)
            else:
                self.logger.info(info)
            
            del self.start_times[operation]


class ErrorTracker:
    """错误追踪器"""
    
    def __init__(self, logger: logging.Logger):
        """初始化错误追踪器"""
        self.logger = logger
        self.error_counts: Dict[str, int] = {}
        self.error_details: Dict[str, list] = {}
    
    def track_error(self, error_type: str, error_message: str, context: Optional[Dict[str, Any]] = None):
        """
        追踪错误
        
        Args:
            error_type: 错误类型
            error_message: 错误信息
            context: 错误上下文
        """
        # 更新错误计数
        self.error_counts[error_type] = self.error_counts.get(error_type, 0) + 1
        
        # 记录错误详情
        error_detail = {
            'timestamp': datetime.now().isoformat(),
            'message': error_message,
            'context': context or {}
        }
        
        if error_type not in self.error_details:
            self.error_details[error_type] = []
        
        self.error_details[error_type].append(error_detail)
        
        # 记录错误日志
        self.logger.error(f"错误类型: {error_type}, 消息: {error_message}, 上下文: {context}")
    
    def get_error_summary(self) -> Dict[str, Any]:
        """
        获取错误摘要
        
        Returns:
            错误摘要信息
        """
        return {
            'total_errors': sum(self.error_counts.values()),
            'error_counts': self.error_counts.copy(),
            'error_types': list(self.error_counts.keys())
        }
    
    def clear_errors(self):
        """清除错误记录"""
        self.error_counts.clear()
        self.error_details.clear()


def setup_logger(name: str = None, log_level: str = "INFO") -> logging.Logger:
    """
    设置日志记录器
    
    Args:
        name: 日志记录器名称
        log_level: 日志级别
        
    Returns:
        配置好的日志记录器
    """
    # TODO: 实现日志记录器设置
    # 1. 从配置中读取日志设置
    # 2. 创建日志记录器
    # 3. 设置日志格式
    # 4. 配置文件和控制台输出
    # 5. 设置日志轮转
    
    try:
        # 获取日志配置
        app_config = config_loader.get_config('app')
        log_config = app_config.get('logging', {})
        
        # 创建日志记录器
        logger_name = name or __name__
        logger = logging.getLogger(logger_name)
        
        # 设置日志级别
        level = getattr(logging, log_config.get('level', log_level).upper())
        logger.setLevel(level)
        
        # 清除现有的处理器
        logger.handlers.clear()
        
        # 创建格式化器
        formatter = logging.Formatter(
            log_config.get('format', '%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        )
        
        # 创建控制台处理器
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setLevel(level)
        console_handler.setFormatter(formatter)
        logger.addHandler(console_handler)
        
        # 创建文件处理器
        log_file = log_config.get('file', 'logs/app.log')
        if log_file:
            # 确保日志目录存在
            log_path = Path(log_file)
            log_path.parent.mkdir(parents=True, exist_ok=True)
            
            # 创建轮转文件处理器
            max_size = log_config.get('max_size', 10) * 1024 * 1024  # MB to bytes
            backup_count = log_config.get('backup_count', 5)
            
            file_handler = logging.handlers.RotatingFileHandler(
                log_file,
                maxBytes=max_size,
                backupCount=backup_count,
                encoding='utf-8'
            )
            file_handler.setLevel(level)
            file_handler.setFormatter(formatter)
            logger.addHandler(file_handler)
        
        # 添加性能日志记录器和错误追踪器
        logger.performance = PerformanceLogger(logger)
        logger.error_tracker = ErrorTracker(logger)
        
        logger.info(f"日志记录器 {logger_name} 设置完成")
        return logger
        
    except Exception as e:
        # 如果配置失败，使用基本的日志记录器
        basic_logger = logging.getLogger(name or __name__)
        basic_logger.setLevel(logging.INFO)
        
        if not basic_logger.handlers:
            handler = logging.StreamHandler(sys.stdout)
            formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
            handler.setFormatter(formatter)
            basic_logger.addHandler(handler)
        
        basic_logger.error(f"日志配置失败: {e}")
        return basic_logger


def log_performance(operation: str):
    """
    性能日志装饰器
    
    Args:
        operation: 操作名称
    """
    def decorator(func):
        @functools.wraps(func)
        async def async_wrapper(*args, **kwargs):
            logger = logging.getLogger(func.__module__)
            logger.performance.start_timer(operation)
            try:
                result = await func(*args, **kwargs)
                logger.performance.end_timer(operation)
                return result
            except Exception as e:
                logger.performance.end_timer(operation, {'error': str(e)})
                raise
        
        @functools.wraps(func)
        def sync_wrapper(*args, **kwargs):
            logger = logging.getLogger(func.__module__)
            logger.performance.start_timer(operation)
            try:
                result = func(*args, **kwargs)
                logger.performance.end_timer(operation)
                return result
            except Exception as e:
                logger.performance.end_timer(operation, {'error': str(e)})
                raise
        
        if asyncio.iscoroutinefunction(func):
            return async_wrapper
        else:
            return sync_wrapper
    
    return decorator


def log_errors(error_type: str = "general"):
    """
    错误日志装饰器
    
    Args:
        error_type: 错误类型
    """
    def decorator(func):
        @functools.wraps(func)
        async def async_wrapper(*args, **kwargs):
            logger = logging.getLogger(func.__module__)
            try:
                result = await func(*args, **kwargs)
                return result
            except Exception as e:
                logger.error_tracker.track_error(
                    error_type,
                    str(e),
                    {
                        'function': func.__name__,
                        'args': str(args),
                        'kwargs': str(kwargs)
                    }
                )
                raise
        
        @functools.wraps(func)
        def sync_wrapper(*args, **kwargs):
            logger = logging.getLogger(func.__module__)
            try:
                result = func(*args, **kwargs)
                return result
            except Exception as e:
                logger.error_tracker.track_error(
                    error_type,
                    str(e),
                    {
                        'function': func.__name__,
                        'args': str(args),
                        'kwargs': str(kwargs)
                    }
                )
                raise
        
        if asyncio.iscoroutinefunction(func):
            return async_wrapper
        else:
            return sync_wrapper
    
    return decorator


class LoggerManager:
    """日志管理器类"""
    
    def __init__(self):
        """初始化日志管理器"""
        self.loggers: Dict[str, logging.Logger] = {}
        self.main_logger = setup_logger("voice_agent")
    
    def get_logger(self, name: str) -> logging.Logger:
        """
        获取日志记录器
        
        Args:
            name: 日志记录器名称
            
        Returns:
            日志记录器
        """
        if name not in self.loggers:
            self.loggers[name] = setup_logger(name)
        
        return self.loggers[name]
    
    def log_system_info(self):
        """记录系统信息"""
        import platform
        import psutil
        
        system_info = {
            'platform': platform.platform(),
            'python_version': platform.python_version(),
            'cpu_count': psutil.cpu_count(),
            'memory_total': psutil.virtual_memory().total,
            'disk_usage': psutil.disk_usage('/').percent
        }
        
        self.main_logger.info(f"系统信息: {system_info}")
    
    def log_performance_metrics(self):
        """记录性能指标"""
        import psutil
        
        cpu_percent = psutil.cpu_percent(interval=1)
        memory = psutil.virtual_memory()
        disk = psutil.disk_usage('/')
        
        metrics = {
            'cpu_usage': f"{cpu_percent}%",
            'memory_usage': f"{memory.percent}%",
            'disk_usage': f"{disk.percent}%",
            'active_loggers': len(self.loggers)
        }
        
        self.main_logger.info(f"性能指标: {metrics}")
    
    def get_error_summary(self) -> Dict[str, Any]:
        """
        获取错误摘要
        
        Returns:
            错误摘要信息
        """
        summary = {}
        for name, logger in self.loggers.items():
            if hasattr(logger, 'error_tracker'):
                summary[name] = logger.error_tracker.get_error_summary()
        
        return summary


# 全局日志管理器实例
logger_manager = LoggerManager()


# 导入asyncio用于装饰器
import asyncio 