"""
Project configuration settings.
"""

import os
from typing import Optional

class Settings:
    """Application settings."""
    
    def __new__(cls):
        if not hasattr(cls, '_instance'):
            cls._instance = super(Settings, cls).__new__(cls)
        return cls._instance
    
    def __init__(self):
        if not hasattr(self, '_initialized'):
            # Server configuration
            self.HOST: str = "0.0.0.0"
            self.PORT: int = 8000
            self.DEBUG: bool = True
            
            # WebSocket configuration
            self.WS_PING_INTERVAL: float = 20.0  # 20 seconds
            self.WS_PING_TIMEOUT: float = 20.0   # 20 seconds
            self.WS_CLOSE_TIMEOUT: float = 5.0   # 5 seconds
            
            # Authentication
            self.DEV_TOKEN: str = "dev_token_1691062800"
            
            # ASR Configuration
            self.ASR_MODEL_PATH: str = r"E:\mnt\e\LLM\ModelScope\SenseVoiceSmall"
            
            # Audio settings
            self.DEFAULT_SAMPLE_RATE: int = 16000
            self.DEFAULT_CHANNELS: int = 1
            self.DEFAULT_SAMPLE_WIDTH: int = 2
            
            # TTS Configuration
            self.DEFAULT_VOICE: str = "zh-CN-XiaoxiaoNeural"
            
            # President TTS Configuration
            self.PRESIDENT_TTS_URL: str = "http://10.120.17.57:9880/tts"
            self.PRESIDENT_REF_AUDIO: str = "ref_audio/ni_zh_01.wav"
            
            # LLM Configuration (DeepSeek)
            self.DEEPSEEK_API_KEY: str = "sk-da5d08fe18c1470db0c40bc874784a59"
            self.DEEPSEEK_BASE_URL: str = "https://api.deepseek.com"
            self.DEEPSEEK_MODEL: str = "deepseek-chat"
            self.DEEPSEEK_TEMPERATURE: float = 0.0
            
            # Agent Configuration
            self.AGENT_MAX_TOKENS: int = 2048
            self.AGENT_TIMEOUT: int = 30
            self.AGENT_RETRY_COUNT: int = 3
            
            # Session Configuration
            self.SESSION_TIMEOUT: int = 3600  # 1 hour
            self.MAX_SESSIONS: int = 100
            self.SESSION_CLEANUP_INTERVAL: int = 300  # 5 minutes
            
            # Status codes
            self.STATUS_SUCCESS: int = 1000
            self.STATUS_AUDIO_FORMAT_ERROR: int = 1001
            self.STATUS_PROCESSING_ERROR: int = 1002
            self.STATUS_SERVER_ERROR: int = 1003
            
            self._initialized = True
    
    def get_asr_model_path(self) -> str:
        """Get ASR model path from environment or default."""
        return os.getenv("ASR_MODEL_PATH", self.ASR_MODEL_PATH)
    
    def get_dev_token(self) -> str:
        """Get development token from environment or default."""
        return os.getenv("DEV_TOKEN", self.DEV_TOKEN)
    
    def get_deepseek_api_key(self) -> str:
        """Get DeepSeek API key from environment or default."""
        return os.getenv("DEEPSEEK_API_KEY", self.DEEPSEEK_API_KEY)

# Global settings instance
settings = Settings() 