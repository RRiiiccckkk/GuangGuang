"""
Test WebSocket backend functionality for audio chat.
"""

import os
import asyncio
import logging
import json
import base64
import websockets
from typing import Dict, Any

# 配置日志
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

async def test_websocket_flow():
    """Test WebSocket audio chat flow."""
    try:
        # WebSocket 连接地址（需要包含认证 token）
        uri = "ws://localhost:8000/api/audio-chat?token=dev_token_1691062800"
        
        async with websockets.connect(uri) as websocket:
            logger.info("Connected to WebSocket server")
            
            # 读取测试音频文件
            audio_file = "examples/test_audio/stream_test_normal.wav"
            with open(audio_file, "rb") as f:
                audio_bytes = f.read()
            
            # 将音频数据转换为 base64
            audio_base64 = base64.b64encode(audio_bytes).decode('utf-8')
            
            # 发送音频消息
            message = {
                "type": "audio",
                "data": audio_base64,
                "sampleRate": 16000,
                "sessionId": "test-session"  # 修复：使用正确的字段名
            }
            logger.info("Sending audio message")
            await websocket.send(json.dumps(message))
            
            # 接收并处理响应
            while True:
                try:
                    response = await websocket.recv()
                    response_data = json.loads(response)
                    
                    if response_data["type"] == "asr_result":
                        logger.info("Received ASR result: %s", response_data["text"])
                        
                    elif response_data["type"] == "audio_chunk":
                        # 处理流式音频块
                        audio_size = len(base64.b64decode(response_data["audio"]))
                        logger.info("Received audio chunk size: %d bytes", audio_size)
                        
                    elif response_data["type"] == "response":
                        logger.info("Received response text: %s", response_data["text"])
                        
                    elif response_data["type"] == "error":
                        logger.error("Received error: %s", response_data["text"])
                        break
                        
                except websockets.exceptions.ConnectionClosed:
                    logger.info("WebSocket connection closed")
                    break
                    
    except Exception as e:
        logger.error("Test failed: %s", str(e))
        raise

if __name__ == "__main__":
    # 设置 DeepSeek API key
    os.environ["DEEPSEEK_API_KEY"] = "sk-da5d08fe18c1470db0c40bc874784a59"
    
    # 运行测试
    asyncio.run(test_websocket_flow()) 