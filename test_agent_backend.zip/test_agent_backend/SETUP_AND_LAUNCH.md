# 智能体语音对话系统 - 设置和启动指南

## 项目概述

这是一个基于LangGraph的智能体语音对话系统，集成了ASR（语音识别）、LLM（大语言模型）、TTS（语音合成）和WebSocket实时通信。

## 系统架构

```
用户语音 → WebSocket → ASR → Agent工作流 → TTS → WebSocket → 用户
```

### 核心组件
- **WebSocket服务器**: 处理实时音频通信
- **ASR管理器**: 语音转文字 (FunASR)
- **Agent工作流**: LangGraph智能体 (DeepSeek)
- **TTS管理器**: 文字转语音 (Edge-TTS)
- **VoiceService**: 核心集成服务

## 启动前准备

### 1. 环境配置
- ✅ Python 3.12
- ✅ Conda环境: `langragh`
- ✅ 所有依赖包已安装

### 2. 缺失文件修复

#### 2.1 修复ASR模块导出
**文件**: `speech/asr/__init__.py`
**问题**: ASRManager类未正确导出
**解决**: 添加 `from .asr_manager import ASRManager` 到 `__all__`

#### 2.2 修复TTS模块导出
**文件**: `speech/tts/__init__.py`
**问题**: TTSManager类未正确导出
**解决**: 添加 `from .tts_manager import TTSManager` 到 `__all__`

#### 2.3 创建WebSocket服务器
**文件**: `websocket/server.py`
**问题**: 文件为空
**解决**: 实现FastAPI WebSocket端点

#### 2.4 创建主启动文件
**文件**: `main.py` 或 `app.py`
**问题**: 缺少主启动文件
**解决**: 创建FastAPI应用和WebSocket路由

### 3. 配置文件检查

#### 3.1 ASR模型路径
**文件**: `config/settings.py`
**检查**: 确保ASR_MODEL_PATH指向正确的FunASR模型

#### 3.2 LLM配置
**文件**: `agent/nodes/nodes.py`
**检查**: 确保DeepSeek API密钥和配置正确

## 启动步骤

### 方法1: 使用主启动文件 (推荐)
```bash
# 1. 激活环境
conda activate langragh

# 2. 运行主启动文件
python main.py
# 或
python app.py
```

### 方法2: 使用uvicorn直接启动
```bash
# 1. 激活环境
conda activate langragh

# 2. 启动WebSocket服务器
uvicorn websocket.server:app --host 0.0.0.0 --port 8000 --reload
```

### 方法3: 使用core/launcher.py
```bash
# 1. 激活环境
conda activate langragh

# 2. 运行启动器
python core/launcher.py
```

## 测试验证

### 1. 服务健康检查
- WebSocket连接: `ws://localhost:8000/ws`
- HTTP健康检查: `http://localhost:8000/health`

### 2. 功能测试
- ASR测试: 发送音频数据，验证语音识别
- Agent测试: 发送文本，验证智能体回复
- TTS测试: 发送文本，验证语音合成
- 端到端测试: 完整语音对话流程

## 常见问题

### 1. 导入错误
**症状**: `ImportError: cannot import name 'XXX'`
**解决**: 检查模块的 `__init__.py` 文件，确保类已正确导出

### 2. 模型加载失败
**症状**: ASR或LLM模型初始化失败
**解决**: 检查模型路径和API密钥配置

### 3. WebSocket连接失败
**症状**: 客户端无法连接到WebSocket
**解决**: 检查端口是否被占用，防火墙设置

### 4. 音频处理错误
**症状**: ASR或TTS处理失败
**解决**: 检查音频格式和采样率设置

## 下一步开发

### 1. 优先级高
- [ ] 修复ASR/TTS模块导出
- [ ] 实现WebSocket服务器
- [ ] 创建主启动文件
- [ ] 测试端到端流程

### 2. 优先级中
- [ ] 添加配置文件管理
- [ ] 实现会话状态持久化
- [ ] 添加错误处理和重试机制
- [ ] 优化音频流处理

### 3. 优先级低
- [ ] 添加用户认证
- [ ] 实现多用户支持
- [ ] 添加监控和日志
- [ ] 性能优化

## 文件结构说明

```
test_agent_backend/
├── agent/                 # 智能体相关
│   ├── nodes/            # 工作流节点
│   ├── graph/            # 工作流图
│   └── state/            # 状态管理
├── speech/               # 语音处理
│   ├── asr/              # 语音识别
│   └── tts/              # 语音合成
├── websocket/            # WebSocket服务
├── services/             # 核心服务
├── llm/                  # 大语言模型
├── tools/                # 工具集
├── config/               # 配置管理
├── core/                 # 核心组件
└── examples/             # 示例和测试
```

## 联系支持

如果遇到问题，请检查：
1. 环境配置是否正确
2. 依赖包是否完整安装
3. 配置文件是否正确
4. 模型文件是否存在 