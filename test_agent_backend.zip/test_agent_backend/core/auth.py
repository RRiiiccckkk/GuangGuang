"""
Authentication manager for token validation.
"""

import logging
from typing import Dict, Optional
from config.settings import settings

logger = logging.getLogger(__name__)

class AuthManager:
    """Authentication manager for handling token validation."""
    
    def __init__(self):
        """Initialize authentication manager."""
        self.valid_tokens: Dict[str, Dict] = {}
        self._load_dev_token()
    
    def _load_dev_token(self):
        """Load development token."""
        dev_token = settings.get_dev_token()
        self.valid_tokens[dev_token] = {
            "type": "dev",
            "expires_at": None  # Dev token doesn't expire
        }
        logger.info("Development token loaded")
    
    def validate_token(self, token: str) -> bool:
        """Validate authentication token.
        
        Args:
            token: Authentication token
            
        Returns:
            bool: True if token is valid, False otherwise
        """
        if not token:
            return False
            
        if token in self.valid_tokens:
            token_info = self.valid_tokens[token]
            # For now, dev token doesn't expire
            return True
            
        logger.warning(f"Invalid token attempted: {token[:10]}...")
        return False
    
    def get_token_info(self, token: str) -> Optional[Dict]:
        """Get token information.
        
        Args:
            token: Authentication token
            
        Returns:
            Dict: Token information or None if invalid
        """
        if self.validate_token(token):
            return self.valid_tokens.get(token)
        return None

# Global authentication manager instance
auth_manager = AuthManager() 