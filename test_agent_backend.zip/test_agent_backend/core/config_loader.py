"""
配置加载器 - 加载和管理全局配置
"""
import os
import yaml
from typing import Dict, Any, Optional
from pathlib import Path


class ConfigLoader:
    """配置加载器类"""
    
    def __init__(self, config_dir: str = "config"):
        """
        初始化配置加载器
        
        Args:
            config_dir: 配置文件目录
        """
        self.config_dir = Path(config_dir)
        self._configs = {}
        self._load_all_configs()
    
    def _load_all_configs(self):
        """加载所有配置文件"""
        config_files = {
            'app': 'app_config.yaml',
            'model': 'model_config.yaml',
            'tool': 'tool_config.yaml'
        }
        
        for config_name, filename in config_files.items():
            config_path = self.config_dir / filename
            if config_path.exists():
                self._configs[config_name] = self._load_yaml(config_path)
            else:
                raise FileNotFoundError(f"配置文件不存在: {config_path}")
    
    def _load_yaml(self, file_path: Path) -> Dict[str, Any]:
        """
        加载YAML配置文件
        
        Args:
            file_path: 配置文件路径
            
        Returns:
            配置字典
        """
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                return yaml.safe_load(f)
        except Exception as e:
            raise RuntimeError(f"加载配置文件失败 {file_path}: {e}")
    
    def get_config(self, config_name: str) -> Dict[str, Any]:
        """
        获取指定配置
        
        Args:
            config_name: 配置名称 (app, model, tool)
            
        Returns:
            配置字典
        """
        if config_name not in self._configs:
            raise KeyError(f"配置不存在: {config_name}")
        return self._configs[config_name]
    
    def get(self, config_name: str, key_path: str, default: Any = None) -> Any:
        """
        获取配置中的特定值
        
        Args:
            config_name: 配置名称
            key_path: 键路径，用点分隔 (如: "server.port")
            default: 默认值
            
        Returns:
            配置值
        """
        config = self.get_config(config_name)
        keys = key_path.split('.')
        
        try:
            value = config
            for key in keys:
                value = value[key]
            return value
        except (KeyError, TypeError):
            return default
    
    def reload_config(self, config_name: str):
        """
        重新加载指定配置
        
        Args:
            config_name: 配置名称
        """
        config_files = {
            'app': 'app_config.yaml',
            'model': 'model_config.yaml',
            'tool': 'tool_config.yaml'
        }
        
        if config_name in config_files:
            config_path = self.config_dir / config_files[config_name]
            if config_path.exists():
                self._configs[config_name] = self._load_yaml(config_path)
    
    def validate_config(self) -> bool:
        """
        验证配置完整性
        
        Returns:
            配置是否有效
        """
        # TODO: 实现配置验证逻辑
        # 检查必需的配置项是否存在
        # 验证配置值的类型和范围
        # 检查文件路径是否存在
        return True


# 全局配置实例
config_loader = ConfigLoader() 