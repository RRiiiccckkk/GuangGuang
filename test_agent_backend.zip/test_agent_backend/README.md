# voice_agent

## 项目简介
voice_agent 是一个基于langgragh为香港科技大学（广州）设计的安卓智能语音agent App，帮助用户便捷获取学术信息、校园资源，并支持语音交互。界面简洁，操作简单，适合所有用户。此项目专注后端开发.
后端需要实现的功能:
-websocket接口
-RAG校园知识查询
-mcp tools开发
-audio and text response 的互补回复模式,语音回复高度概括, 文字信息补充不能用语言传递的信息,如网址,和补充详细信息
-音色切换, 在语音中接受到切换为倪校长/倪宝指令, 音色切换成倪校长音色
-校园知识库搜索:使用data文件夹中数据进行检索

## 项目架构设计
voice_assistant_backend/
├── core/                     # 核心服务（启动入口+全局管理）
│   ├── launcher.py           # 服务启动器（预热模型、初始化模块）
│   └── config_loader.py      # 加载全局配置（模型路径、端口等）
│
├── websocket/                # WebSocket通信层
│   ├── server.py             # WebSocket服务器（监听连接、收发消息）
│   ├── message_handler.py    # 解析前端消息（区分音频/文本输入）
│   └── stream_sender.py      # 流式推送（文本片段/音频片段给前端）
│
├── agent/                    # LangGraph Agent核心
│   ├── state/                # 定义Agent状态（流转的数据载体）
│   ├── nodes/                # 图节点（处理逻辑单元）
│   ├── graph/                # 图流程（节点连接+执行顺序）
│   └── memory/               # 对话记忆（上下文存储+摘要）
│
├── tools/                    # Agent可调用的工具集
│   ├── rag/                  # RAG知识库工具（查询校园资讯等）
│   ├── web_search/           # 网页访问工具
│   ├── calendar/             # 日历工具
│   └── tool_registry.py      # 工具注册中心（Agent统一调用入口）
│
├── speech/                   # 语音处理模块（ASR+TTS）
│   ├── asr/                  # 语音转文字
│   │   ├── stream_processor.py  # 流式处理音频片段
│   │   └── asr_engine.py        # 调用ASR模型（本地/API）
│   └── tts/                  # 文字转语音
│       ├── stream_converter.py  # 流式转换文本片段为音频
│       └── tts_engine.py        # 调用TTS模型（本地/API）
│
├── llm/                      # LLM管理（本地大模型/API）
│   ├── model_loader.py       # 加载本地大模型（预热时初始化）
│   ├── stream_generator.py   # LLM流式生成文本
│   └── api_client.py         # 若用API，封装调用逻辑
│
├── utils/                    # 通用工具
│   ├── logger.py             # 日志记录（延迟监控、错误追踪）
│   ├── audio_utils.py        # 音频格式处理（转码、分片）
│   └── cache.py              # 缓存（高频RAG结果、工具调用结果）
│
└── config/                   # 配置文件
    ├── app_config.yaml       # 应用配置（端口、超时时间）
    ├── model_config.yaml     # 模型配置（路径、参数）
    └── tool_config.yaml      # 工具配置（RAG路径、API密钥）



### 语音聊天 WebSocket 接口
```
WebSocket /api/audio-chat

1. 连接建立
ws://your-server:8000/api/audio-chat?token=<认证token>

2. 客户端发送消息格式：
{
    "type": "audio",           // 消息类型：audio
    "data": string,           // 音频数据（base64编码的WAV格式）
    "sampleRate": number,     // 采样率（默认16000）
    "format": "wav"          // 音频格式
}

3. 服务器返回消息格式：

**ASR识别结果：**
{
    "type": "asr_result",     // 语音识别结果
    "text": string,          // 识别的文本
    "status": {
        "code": number,      // 状态码
        "message": string    // 状态信息
    }
}

**音频块（流式TTS）：**
{
    "type": "audio_chunk",    // 音频块消息
    "audio": string,         // base64编码的音频数据块
    "status": {
        "code": number,      // 状态码
        "message": string    // 状态信息
    }
}

**文本响应：**
{
    "type": "response",       // 对话回复
    "text": string,          // 回复文本
    "status": {
        "code": number,      // 状态码
        "message": string    // 状态信息
    }
}

4. 状态码定义：
- 1000：正常
- 1001：音频格式错误
- 1002：识别/处理失败
- 1003：服务器错误

5. 特性说明：
- **ASR识别**：返回语音识别文本
- **Agent流式生成**：LangGraph Agent流式生成回复文本
- **流式TTS**：每生成一段文本立即进行TTS转换，并流式发送音频块
- **消息类型**：
  - `asr_result`：语音识别结果
  - `audio_chunk`：流式音频块（每个音频块生成后立即发送）
  - `response`：完整的文本响应（在音频发送完毕后）
- **实时性**：音频块实时发送，无需等待完整响应
- **错误处理**：即使TTS失败也会发送文本响应
- **会话管理**：支持多会话状态管理

6. 优化说明：
- 服务器保持模型常驻内存
- 使用流式处理减少延迟

7. 流式处理流程：
```
客户端发送音频 → ASR识别 → Agent流式生成文本 → 流式TTS → 实时发送音频块 → 发送完整文本响应
```

**详细流程：**
1. **音频输入**：客户端发送base64编码的音频数据
2. **ASR识别**：服务器识别音频并返回 `asr_result` 消息
3. **Agent处理**：LangGraph Agent流式生成回复文本
4. **流式TTS**：每生成一段文本立即进行TTS转换
5. **音频块发送**：每个音频块生成后立即发送 `audio_chunk` 消息
6. **文本响应**：所有音频块发送完毕后，发送 `response` 消息包含完整文本

**优势：**
- 真正的流式体验，客户端可以实时播放音频
- 无需等待完整响应，减少延迟
- 支持长文本的实时语音合成

**音色切换功能：**
- 支持两种音色模式：普通音色（女声）和校长音色（男声）
- 当Agent检测到"倪校长"或"倪宝"指令时，自动切换到校长音色
- 音色切换通过 `voice_mode` 参数控制：
  - `VoiceMode.NORMAL`：普通音色（zh-CN-XiaoxiaoNeural）
  - `VoiceMode.PRESIDENT`：校长音色（zh-CN-YunxiNeural）

8. 认证说明：
- 开发测试阶段使用固定token: dev_token_1691062800
- 可以通过 GET /api/token 获取当前有效的token和WebSocket连接URL
- token必须作为URL参数传递，否则连接会被拒绝（403 Forbidden）

9. 获取Token API：
GET http://your-server:8000/api/token

返回格式：
{
    "token": "dev_token_1691062800",
    "usage": "ws://localhost:8000/api/audio-chat?token=dev_token_1691062800"
}

10. 连接示例：

**Python示例：**
```python
import websockets
import json
import base64

# 建立WebSocket连接
uri = "ws://your-server:8000/api/audio-chat?token=dev_token_1691062800"
async with websockets.connect(uri) as websocket:
    # 发送音频数据
    message = {
        "type": "audio",
        "data": "<base64音频数据>",
        "sampleRate": 16000,
        "format": "wav"
    }
    await websocket.send(json.dumps(message))
    
    # 接收流式响应
    audio_chunks = []
    async for response in websocket:
        data = json.loads(response)
        
        if data["type"] == "asr_result":
            print(f"ASR结果: {data['text']}")
            
        elif data["type"] == "audio_chunk":
            # 收集音频块
            audio_chunks.append(data["audio"])
            print(f"收到音频块，大小: {len(data['audio'])}")
            
        elif data["type"] == "response":
            print(f"完整回复: {data['text']}")
            # 拼接所有音频块
            full_audio = b"".join([base64.b64decode(chunk) for chunk in audio_chunks])
            print(f"完整音频大小: {len(full_audio)} bytes")
```

**Dart/Flutter示例：**
```dart
import 'dart:convert';
import 'dart:typed_data';
import 'package:web_socket_channel/web_socket_channel.dart';

// 建立WebSocket连接
final wsUrl = 'ws://your-server:8000/api/audio-chat?token=dev_token_1691062800';
final channel = WebSocketChannel.connect(Uri.parse(wsUrl));

// 发送音频数据
final message = {
    'type': 'audio',
    'data': '<base64音频数据>',
    'sampleRate': 16000,
    'format': 'wav'
};
channel.sink.add(jsonEncode(message));

// 接收流式响应
List<String> audioChunks = [];
channel.stream.listen((response) {
    final data = jsonDecode(response);
    
    switch (data['type']) {
        case 'asr_result':
            print('ASR结果: ${data['text']}');
            break;
            
        case 'audio_chunk':
            // 收集音频块
            audioChunks.add(data['audio']);
            print('收到音频块，大小: ${data['audio'].length}');
            break;
            
        case 'response':
            print('完整回复: ${data['text']}');
            // 拼接所有音频块
            final fullAudio = audioChunks
                .map((chunk) => base64Decode(chunk))
                .expand((bytes) => bytes)
                .toList();
            print('完整音频大小: ${fullAudio.length} bytes');
            break;
    }
});
```

注意：
1. 所有 API 接口都应返回统一的响应格式：
```
{
    "code": number,     // 状态码，200 表示成功
    "message": string,  // 状态信息
    "data": object     // 响应数据
}
```

2. 错误处理：
- 400：请求参数错误
- 401：未授权
- 404：资源不存在
- 500：服务器内部错误

3. 认证：
- 所有接口都需要在请求头中携带 token：
```
Authorization: Bearer <token>
```

#tool开发与测试
1. 在tool文件中增加自己的tool
2. 在agent/nodes/nodes.py 中将自己的工具添加到ToolNode中,例:
tools = [search_shanghai_location]
3. 使用examples/test_graph.py测试工具,例:
    initial_state = {
        "messages": [HumanMessage(content="Where is shanghai?")]
    }

#RAG与Memory

#asr,agent, tts, websocket
1.暂时不使用agentstate,使用langgraph自带的MessageState简化开发,后续再迭代