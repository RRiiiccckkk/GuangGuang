"""
网页搜索工具模块
"""

from .web_searcher import web_searcher

__all__ = ['web_searcher'] 