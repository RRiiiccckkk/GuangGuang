"""
Weather forecast tool provider.

Provides tools for retrieving weather forecasts, alerts, and assessing running conditions.
"""

from typing import Any, Dict
from langchain_core.tools import tool
import httpx

@tool
async def get_weather_forecast(latitude:float,longitude:float)->str:
    """
    Get the weather forecast for a given latitude and longitude.

    Args:
        latitude: The latitude of the location to get the weather forecast for.
        longitude: The longitude of the location to get the weather forecast for.

    Returns:
        A string containing the weather forecast for the given latitude and longitude.
    """
    async with httpx.AsyncClient() as client:
        try:
        response=await client.get(
            f"https://api.open-meteo.com/v1/forecast?latitude={latitude}&longitude={longitude}&current_weather=true"
        )
            return response.json()
        except httpx.HTTPStatusError as e:
            return f"Error fetching weather forecast: {e}"
    
# @tool
# async def get_weather_alerts(state:str)->str:
#     """
#     Get the weather alerts for a given state.

#     Args:
#         state: The state to get the weather alerts for.

#     Returns:
#         A string containing the weather alerts for the given state.
#     """
#     async with httpx.AsyncClient() as client:
