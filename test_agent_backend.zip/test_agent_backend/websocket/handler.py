"""
WebSocket handler for audio chat.
"""

import logging
import json
from typing import Dict, Any

from fastapi import WebSocket
from services.voice_service import VoiceService
from config.settings import settings

logger = logging.getLogger(__name__)

class AudioChatHandler:
    """Handler for audio chat WebSocket connections."""
    
    def __init__(self):
        """Initialize audio chat handler."""
        self.voice_service = VoiceService()
        self.active_connections: Dict[str, WebSocket] = {}
        
    async def connect(self, websocket: WebSocket, client_id: str):
        """Handle WebSocket connection."""
        await websocket.accept()
        self.active_connections[client_id] = websocket
        logger.info(f"Client connected: {client_id}")
        
    def disconnect(self, client_id: str):
        """Handle WebSocket disconnection."""
        if client_id in self.active_connections:
            del self.active_connections[client_id]
            logger.info(f"Client disconnected: {client_id}")
            
    async def handle_message(self, websocket: WebSocket, client_id: str, message: Dict[str, Any]):
        """Handle incoming WebSocket message."""
        try:
            message_type = message.get("type")
            
            if message_type == "audio":
                await self._handle_audio_message(
                    websocket,
                    client_id,
                    message.get("sessionId", client_id),  # 修复：使用正确的字段名
                    message
                )
            elif message_type == "ping":
                await websocket.send_json({"type": "pong"})
            else:
                logger.warning(f"Unknown message type: {message_type}")
                await websocket.send_json({
                    "type": "error",
                    "text": "Unknown message type",
                    "status": {"code": settings.STATUS_PROCESSING_ERROR, "message": "Invalid message type"}
                })
                
        except Exception as e:
            logger.error(f"Error handling message: {str(e)}")
            await websocket.send_json({
                "type": "error",
                "text": "Message handling failed",
                "status": {"code": settings.STATUS_PROCESSING_ERROR, "message": str(e)}
            })
            
    async def _handle_audio_message(
        self,
        websocket: WebSocket,
        client_id: str,
        session_id: str,
        message: Dict[str, Any]
    ):
        """Handle audio message."""
        try:
            # Process audio and stream responses using VoiceService with LangGraph agent
            async for response in self.voice_service.process_audio(
                message["data"],
                message.get("sampleRate", settings.DEFAULT_SAMPLE_RATE),
                session_id
            ):
                await websocket.send_json(response)
                
        except Exception as e:
            logger.error(f"Error processing audio: {str(e)}")
            await websocket.send_json({
                "type": "error",
                "text": "Audio processing failed",
                "status": {"code": settings.STATUS_PROCESSING_ERROR, "message": str(e)}
            })
            
    async def close(self):
        """Close handler and cleanup resources."""
        try:
            await self.voice_service.close()
        except Exception as e:
            logger.error(f"Error closing handler: {str(e)}")

# Create singleton handler instance
audio_chat_handler = AudioChatHandler() 