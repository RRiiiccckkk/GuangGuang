"""
WebSocket message types and schemas.
"""

from typing import Dict, Any, Optional
from dataclasses import dataclass
from enum import Enum
import json

class MessageType(Enum):
    """WebSocket message types."""
    AUDIO = "audio"
    ASR_RESULT = "asr_result"
    RESPONSE = "response"
    AUDIO_CHUNK = "audio_chunk"  # 新增：音频块消息类型
    ERROR = "error"
    PING = "ping"
    PONG = "pong"

@dataclass
class AudioMessage:
    """Audio message from client."""
    type: str = MessageType.AUDIO.value
    data: str = ""  # Base64 encoded audio data
    sampleRate: int = 16000
    format: str = "wav"
    sessionId: Optional[str] = None

@dataclass
class ASRResultMessage:
    """ASR result message to client."""
    type: str = MessageType.ASR_RESULT.value
    text: str = ""
    status: Dict[str, Any] = None
    
    def __post_init__(self):
        if self.status is None:
            self.status = {"code": 1000, "message": "Success"}

@dataclass
class ResponseMessage:
    """Response message to client."""
    type: str = MessageType.RESPONSE.value
    text: str = ""
    display_text: str = ""
    audio: str = ""  # Base64 encoded audio data
    status: Dict[str, Any] = None
    
    def __post_init__(self):
        if self.status is None:
            self.status = {"code": 1000, "message": "Success"}

@dataclass
class AudioChunkMessage:
    """Audio chunk message to client."""
    type: str = MessageType.AUDIO_CHUNK.value
    audio: str = ""  # Base64 encoded audio data
    status: Dict[str, Any] = None
    
    def __post_init__(self):
        if self.status is None:
            self.status = {"code": 1000, "message": "Audio chunk"}

@dataclass
class ErrorMessage:
    """Error message to client."""
    type: str = MessageType.ERROR.value
    message: str = ""
    status: Dict[str, Any] = None
    
    def __post_init__(self):
        if self.status is None:
            self.status = {"code": 1003, "message": "Server error"}

class MessageParser:
    """Message parser for WebSocket messages."""
    
    @staticmethod
    def parse_client_message(message: str) -> Dict[str, Any]:
        """Parse client message from JSON string.
        
        Args:
            message: JSON message string
            
        Returns:
            Parsed message dictionary
            
        Raises:
            ValueError: If message parsing fails
        """
        try:
            data = json.loads(message)
            
            # Validate required fields
            if "type" not in data:
                raise ValueError("Missing 'type' field in message")
            
            message_type = data["type"]
            
            if message_type == MessageType.AUDIO.value:
                return MessageParser._parse_audio_message(data)
            elif message_type == MessageType.PING.value:
                return {"type": MessageType.PING.value}
            else:
                raise ValueError(f"Unknown message type: {message_type}")
                
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON format: {e}")
        except Exception as e:
            raise ValueError(f"Message parsing error: {e}")
    
    @staticmethod
    def _parse_audio_message(data: Dict[str, Any]) -> Dict[str, Any]:
        """Parse audio message data.
        
        Args:
            data: Raw message data
            
        Returns:
            Parsed audio message
            
        Raises:
            ValueError: If audio message is invalid
        """
        # Validate required fields
        if "data" not in data:
            raise ValueError("Missing 'data' field in audio message")
        
        audio_data = data["data"]
        if not isinstance(audio_data, str) or not audio_data.strip():
            raise ValueError("Invalid or empty audio data")
        
        # Parse optional fields
        sample_rate = data.get("sampleRate", 16000)
        if not isinstance(sample_rate, int) or sample_rate <= 0:
            raise ValueError("Invalid sample rate")
        
        format_type = data.get("format", "wav")
        if not isinstance(format_type, str) or format_type.lower() not in ["wav", "mp3"]:
            raise ValueError("Invalid audio format")
        
        session_id = data.get("sessionId")
        if session_id is not None and not isinstance(session_id, str):
            raise ValueError("Invalid session ID")
        
        return {
            "type": MessageType.AUDIO.value,
            "data": audio_data,
            "sampleRate": sample_rate,
            "format": format_type.lower(),
            "sessionId": session_id
        }
    
    @staticmethod
    def create_asr_result_message(text: str, status_code: int = 1000) -> str:
        """Create ASR result message.
        
        Args:
            text: Recognized text
            status_code: Status code
            
        Returns:
            JSON message string
        """
        status_messages = {
            1000: "Success",
            1001: "Audio format error",
            1002: "Processing error",
            1003: "Server error"
        }
        
        message = ASRResultMessage(
            text=text,
            status={
                "code": status_code,
                "message": status_messages.get(status_code, "Unknown error")
            }
        )
        
        return json.dumps(message.__dict__)
    
    @staticmethod
    def create_response_message(
        text: str,
        display_text: str,
        audio: str,
        status_code: int = 1000
    ) -> str:
        """Create response message.
        
        Args:
            text: Voice response text
            display_text: Display response text
            audio: Base64 encoded audio data
            status_code: Status code
            
        Returns:
            JSON message string
        """
        status_messages = {
            1000: "Success",
            1001: "Audio format error",
            1002: "Processing error",
            1003: "Server error"
        }
        
        message = ResponseMessage(
            text=text,
            display_text=display_text,
            audio=audio,
            status={
                "code": status_code,
                "message": status_messages.get(status_code, "Unknown error")
            }
        )
        
        return json.dumps(message.__dict__)
    
    @staticmethod
    def create_audio_chunk_message(
        audio: str,
        status_code: int = 1000
    ) -> str:
        """Create audio chunk message.
        
        Args:
            audio: Base64 encoded audio data
            status_code: Status code
            
        Returns:
            JSON message string
        """
        status_messages = {
            1000: "Audio chunk",
            1002: "Processing error",
            1003: "Server error"
        }
        
        message = AudioChunkMessage(
            audio=audio,
            status={
                "code": status_code,
                "message": status_messages.get(status_code, "Unknown error")
            }
        )
        
        return json.dumps(message.__dict__)
    
    @staticmethod
    def create_error_message(message: str, status_code: int = 1003) -> str:
        """Create error message.
        
        Args:
            message: Error message
            status_code: Status code
            
        Returns:
            JSON message string
        """
        status_messages = {
            1001: "Audio format error",
            1002: "Processing error",
            1003: "Server error"
        }
        
        error_msg = ErrorMessage(
            message=message,
            status={
                "code": status_code,
                "message": status_messages.get(status_code, "Unknown error")
            }
        )
        
        return json.dumps(error_msg.__dict__)
    
    @staticmethod
    def create_pong_message() -> str:
        """Create pong message.
        
        Returns:
            JSON message string
        """
        return json.dumps({"type": MessageType.PONG.value})

# Message validation schemas
AUDIO_MESSAGE_SCHEMA = {
    "type": "object",
    "properties": {
        "type": {"type": "string", "enum": ["audio"]},
        "data": {"type": "string", "minLength": 1},
        "sampleRate": {"type": "integer", "minimum": 8000, "maximum": 48000},
        "format": {"type": "string", "enum": ["wav", "mp3"]},
        "sessionId": {"type": "string"}
    },
    "required": ["type", "data"],
    "additionalProperties": False
} 