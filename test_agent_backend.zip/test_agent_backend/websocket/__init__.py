"""
WebSocket通信模块
""" 