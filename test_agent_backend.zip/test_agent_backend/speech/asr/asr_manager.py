"""
ASR (Automatic Speech Recognition) Manager
Enhanced version based on reference implementation
"""

import os
import wave
import tempfile
import logging
import base64
from typing import Optional, Dict, Any
from funasr import AutoModel

from config.settings import settings

logger = logging.getLogger(__name__)

class ASRManager:
    """Enhanced ASR manager with improved error handling and real-time response"""
    
    def __init__(self, model_path: Optional[str] = None):
        """Initialize ASR manager with FunASR model
        
        Args:
            model_path: Path to the FunASR model. If None, uses config default.
        """
        self.model_path = model_path or settings.ASR_MODEL_PATH
        self.model = None
        self._initialized = False
        logger.info(f"ASR Manager initialized with model path: {self.model_path}")
        
    def initialize(self) -> bool:
        """Initialize the ASR model
        
        Returns:
            bool: True if initialization successful, False otherwise
        """
        if self._initialized:
            return True
            
        try:
            if not os.path.exists(self.model_path):
                logger.error(f"Model path does not exist: {self.model_path}")
                return False
                
            logger.info(f"Loading ASR model from: {self.model_path}")
            self.model = AutoModel(
                model=self.model_path,
                trust_remote_code=True,
                disable_update=True,
            )
            self._initialized = True
            logger.info("ASR model initialized successfully")
            return True
            
        except Exception as e:
            logger.error(f"Failed to initialize ASR model: {str(e)}")
            return False

    async def process_audio_bytes(self, audio_bytes: bytes, sample_rate: int = 16000) -> Dict[str, Any]:
        """Process audio from bytes data and return recognized text
        
        Args:
            audio_bytes: Raw audio data in bytes
            sample_rate: Sample rate of the audio (default: 16000)
            
        Returns:
            Dict containing:
                - text: Recognized text
                - status: Recognition status
        """
        if not self._initialized and not self.initialize():
            return {
                "text": "ASR服务未初始化",
                "status": {"code": 1002, "message": "ASR initialization failed"}
            }

        # 创建临时文件
        with tempfile.NamedTemporaryFile(suffix='.wav', delete=False) as temp_file:
            try:
                logger.debug(f"Processing audio bytes of size: {len(audio_bytes)}")
                
                # 保存音频数据到临时WAV文件
                self._save_audio_file(audio_bytes, temp_file.name, sample_rate=sample_rate)
                logger.debug(f"Saved audio to temporary file: {temp_file.name}")
                
                # ASR识别
                logger.info("Starting ASR recognition...")
                res = self.model.generate(
                    input=temp_file.name,
                    cache={},
                    language="zh",
                    use_itn=True,
                )
                logger.debug(f"ASR raw result: {res}")
                
                # 提取文本结果
                text = res[0]['text'] if isinstance(res, list) and len(res) > 0 else ""
                text = text.split(">")[-1].strip() if ">" in text else text.strip()
                
                return {
                    "text": text if text else "未能识别语音内容",
                    "status": {"code": 1000, "message": "Success"}
                }
                
            except Exception as e:
                error_msg = f"语音识别出错: {str(e)}"
                logger.error(error_msg)
                return {
                    "text": error_msg,
                    "status": {"code": 1002, "message": str(e)}
                }
            finally:
                # 删除临时文件
                try:
                    os.unlink(temp_file.name)
                except:
                    pass

    async def process_audio(self, audio_data: str) -> str:
        """Process base64 encoded audio data and return recognized text
        
        Args:
            audio_data: Base64 encoded audio data
            
        Returns:
            str: Recognized text
        """
        try:
            # 解码 base64 数据
            audio_bytes = base64.b64decode(audio_data)
            result = await self.process_audio_bytes(audio_bytes)
            return result["text"]
        except Exception as e:
            logger.error(f"Error processing audio: {e}")
            return "音频数据处理失败"

    @staticmethod
    def _save_audio_file(audio_data: bytes, output_path: str, channels: int = 1, 
                        sample_width: int = 2, sample_rate: int = 16000):
        """Save audio data to WAV file
        
        Args:
            audio_data: Raw audio data in bytes
            output_path: Path to save the WAV file
            channels: Number of audio channels
            sample_width: Sample width in bytes (2 for 16-bit PCM)
            sample_rate: Sample rate of the audio
        """
        with wave.open(output_path, 'wb') as wf:
            wf.setnchannels(channels)
            wf.setsampwidth(sample_width)
            wf.setframerate(sample_rate)
            wf.writeframes(audio_data) 