"""
TTS语音合成模块
"""

from .tts_manager import TTSManager, VoiceMode

__all__ = ['TTSManager', 'VoiceMode'] 