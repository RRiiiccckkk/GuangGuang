"""
TTS manager for handling text-to-speech conversion using edge-tts.
"""

import logging
import asyncio
import base64
from enum import Enum
from typing import Optional, AsyncGenerator
from edge_tts import Communicate
from io import BytesIO

logger = logging.getLogger(__name__)

class VoiceMode(Enum):
    """Voice mode enumeration."""
    NORMAL = "normal"
    PRESIDENT = "president"

class TTSManager:
    """Manager for text-to-speech conversion using edge-tts."""
    
    def __init__(self):
        """Initialize TTS manager."""
        # 使用中文女声作为普通语音
        self.normal_voice = "zh-CN-XiaoxiaoNeural"
        # 使用中文男声作为校长语音
        self.president_voice = "zh-CN-YunxiNeural"
        logger.info("TTS Manager initialized with voices: normal=%s, president=%s", 
                   self.normal_voice, self.president_voice)
        
    async def stream_tts(
        self,
        text: str,
        voice_mode: VoiceMode = VoiceMode.NORMAL,
        chunk_size: int = 4096
    ) -> AsyncGenerator[bytes, None]:
        """Stream TTS audio in chunks.
        
        Args:
            text: Text to convert to speech
            voice_mode: Voice mode to use
            chunk_size: Size of audio chunks
            
        Yields:
            Audio data chunks
        """
        try:
            # 选择语音
            voice = self.president_voice if voice_mode == VoiceMode.PRESIDENT else self.normal_voice
            logger.info("Converting text to speech: %s (voice=%s, mode=%s)", 
                       text, voice, voice_mode.value)
            
            # 创建 edge-tts 通信对象
            communicate = Communicate(text, voice)
            logger.debug("Created edge-tts communicate object")
            
            # 获取音频流
            audio_stream = BytesIO()
            chunk_count = 0
            async for chunk in communicate.stream():
                if chunk["type"] == "audio":
                    audio_data = chunk["data"]
                    audio_stream.write(audio_data)
                    logger.debug("Received audio data chunk of size: %d bytes", len(audio_data))
                    
                    # 如果累积的数据超过 chunk_size，就返回一个块
                    if audio_stream.tell() >= chunk_size:
                        audio_stream.seek(0)
                        chunk_count += 1
                        data = audio_stream.read(chunk_size)
                        logger.info("Yielding audio chunk #%d of size: %d bytes", 
                                  chunk_count, len(data))
                        yield data
                        
                        # 保留剩余数据
                        remaining_data = audio_stream.read()
                        audio_stream = BytesIO()
                        audio_stream.write(remaining_data)
                        logger.debug("Remaining data size: %d bytes", len(remaining_data))
            
            # 返回最后的数据块
            if audio_stream.tell() > 0:
                audio_stream.seek(0)
                chunk_count += 1
                data = audio_stream.read()
                logger.info("Yielding final audio chunk #%d of size: %d bytes", 
                          chunk_count, len(data))
                yield data
                            
        except Exception as e:
            logger.error(f"{voice_mode.value.title()} TTS generation failed: {str(e)}")
            raise
            
    async def close(self):
        """Close TTS manager and cleanup resources."""
        logger.debug("Closing TTS manager")
        pass  # No cleanup needed for edge-tts 