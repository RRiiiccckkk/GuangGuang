"""
LLM流式生成器 - LLM流式生成文本
"""
import asyncio
import logging
from typing import Dict, Any, Optional, AsyncGenerator, List

from .model_loader import model_loader


class StreamGenerator:
    """LLM流式生成器类"""
    
    def __init__(self):
        """初始化流式生成器"""
        self.logger = logging.getLogger(__name__)
        self.chunk_size = 50  # 默认文本块大小
    
    async def generate_stream(self, prompt: str, **kwargs) -> AsyncGenerator[str, None]:
        """
        流式生成文本
        
        Args:
            prompt: 输入提示
            **kwargs: 生成参数
            
        Yields:
            生成的文本片段
        """
        # TODO: 实现流式文本生成逻辑
        # 1. 设置生成参数
        # 2. 调用模型进行流式生成
        # 3. 按块大小分割文本
        # 4. 实时返回文本片段
        
        try:
            # 获取生成参数
            generation_params = self._prepare_generation_params(**kwargs)
            
            # 调用模型进行流式生成
            async for token in model_loader.generate_stream(prompt, **generation_params):
                # 处理生成的token
                if token:
                    # 按块大小分割并返回
                    chunks = self._split_into_chunks(token)
                    for chunk in chunks:
                        if chunk.strip():
                            yield chunk
                            
        except Exception as e:
            self.logger.error(f"流式生成失败: {e}")
            yield f"生成过程中出现错误: {str(e)}"
    
    def _prepare_generation_params(self, **kwargs) -> Dict[str, Any]:
        """
        准备生成参数
        
        Args:
            **kwargs: 用户提供的参数
            
        Returns:
            处理后的生成参数
        """
        # TODO: 实现参数准备逻辑
        # 1. 设置默认参数
        # 2. 合并用户参数
        # 3. 验证参数有效性
        # 4. 返回最终参数
        
        default_params = {
            'temperature': 0.7,
            'top_p': 0.9,
            'max_length': 2048,
            'repetition_penalty': 1.1,
            'do_sample': True,
            'pad_token_id': 0,
            'eos_token_id': 2
        }
        
        # 合并用户参数
        generation_params = {**default_params, **kwargs}
        
        # 验证参数
        self._validate_params(generation_params)
        
        return generation_params
    
    def _validate_params(self, params: Dict[str, Any]):
        """
        验证生成参数
        
        Args:
            params: 生成参数
        """
        # TODO: 实现参数验证逻辑
        # 1. 检查必需参数
        # 2. 验证参数范围
        # 3. 检查参数类型
        
        if 'temperature' in params:
            temp = params['temperature']
            if not (0 <= temp <= 2):
                raise ValueError(f"温度参数必须在0-2之间，当前值: {temp}")
        
        if 'top_p' in params:
            top_p = params['top_p']
            if not (0 < top_p <= 1):
                raise ValueError(f"top_p参数必须在0-1之间，当前值: {top_p}")
        
        if 'max_length' in params:
            max_len = params['max_length']
            if max_len <= 0:
                raise ValueError(f"最大长度必须大于0，当前值: {max_len}")
    
    def _split_into_chunks(self, text: str) -> List[str]:
        """
        将文本分割成块
        
        Args:
            text: 输入文本
            
        Returns:
            文本块列表
        """
        # TODO: 实现文本分块逻辑
        # 1. 按句子分割
        # 2. 按字符数分割
        # 3. 保持语义完整性
        
        if len(text) <= self.chunk_size:
            return [text]
        
        chunks = []
        current_chunk = ""
        
        # 按句子分割
        sentences = text.split('。')
        
        for sentence in sentences:
            if not sentence.strip():
                continue
                
            if len(current_chunk + sentence) <= self.chunk_size:
                current_chunk += sentence + "。"
            else:
                if current_chunk:
                    chunks.append(current_chunk.strip())
                current_chunk = sentence + "。"
        
        if current_chunk:
            chunks.append(current_chunk.strip())
        
        return chunks
    
    async def generate_with_memory(self, prompt: str, memory: List[Dict[str, Any]], **kwargs) -> AsyncGenerator[str, None]:
        """
        带记忆的流式生成
        
        Args:
            prompt: 输入提示
            memory: 对话记忆
            **kwargs: 生成参数
            
        Yields:
            生成的文本片段
        """
        # TODO: 实现带记忆的生成逻辑
        # 1. 构建包含记忆的完整提示
        # 2. 调用流式生成
        # 3. 返回生成结果
        
        # 构建完整提示
        full_prompt = self._build_prompt_with_memory(prompt, memory)
        
        # 流式生成
        async for chunk in self.generate_stream(full_prompt, **kwargs):
            yield chunk
    
    def _build_prompt_with_memory(self, prompt: str, memory: List[Dict[str, Any]]) -> str:
        """
        构建包含记忆的提示
        
        Args:
            prompt: 当前提示
            memory: 对话记忆
            
        Returns:
            完整的提示文本
        """
        # TODO: 实现提示构建逻辑
        # 1. 格式化历史对话
        # 2. 添加当前提示
        # 3. 设置系统提示
        
        if not memory:
            return prompt
        
        # 构建历史对话
        history = ""
        for item in memory[-5:]:  # 只保留最近5轮对话
            if 'user' in item and 'assistant' in item:
                history += f"用户: {item['user']}\n"
                history += f"助手: {item['assistant']}\n"
        
        # 构建完整提示
        full_prompt = f"{history}用户: {prompt}\n助手: "
        
        return full_prompt
    
    def set_chunk_size(self, size: int):
        """
        设置文本块大小
        
        Args:
            size: 块大小
        """
        if size <= 0:
            raise ValueError("块大小必须大于0")
        self.chunk_size = size


# 全局流式生成器实例
stream_generator = StreamGenerator() 